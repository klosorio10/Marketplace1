package controllers;

import akka.dispatch.MessageDispatcher;
import com.fasterxml.jackson.databind.JsonNode;
import dispatchers.AkkaDispatcher;
import models.WishListEntity;
import play.libs.Json;
import play.mvc.Controller;
import play.mvc.Result;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.CompletionStage;

import static play.libs.Json.toJson;

public class WishListController extends Controller
{

    public CompletionStage<Result> getAllWishLists() {
        MessageDispatcher jdbcDispatcher = AkkaDispatcher.jdbcDispatcher;

        return CompletableFuture.
                supplyAsync(
                        () -> {
                            return WishListEntity.FINDER.all();
                        }
                        ,jdbcDispatcher)
                .thenApply(
                        wishListEntities -> {
                            return ok(toJson(wishListEntities));
                        }
                );
    }

    public CompletionStage<Result> createWishList()
    {
        MessageDispatcher jdbcDispatcher = AkkaDispatcher.jdbcDispatcher;
        JsonNode nWishList = request().body().asJson();
        WishListEntity wlist = Json.fromJson( nWishList , WishListEntity.class ) ;
        return CompletableFuture.supplyAsync(
                ()->{
                    wlist.save();
                    return wlist;
                }
        ).thenApply(
                wishListEntity -> {
                    return ok(Json.toJson(wishListEntity));
                }
        );
    }




}
