# --- Created by Ebean DDL
# To stop Ebean DDL generation, remove this comment and start using Evolutions

# --- !Ups

create table itementity (
  id                            bigint not null,
  quantity                      integer,
  product_id                    bigint,
  wish_list_id                  bigint,
  constraint pk_itementity primary key (id)
);
create sequence Item;

create table productentity (
  id                            bigint not null,
  name                          varchar(255),
  stock                         integer,
  price                         float,
  available                     boolean,
  constraint pk_productentity primary key (id)
);
create sequence Product;

create table wishlistentity (
  id                            bigint not null,
  username                      varchar(255),
  constraint pk_wishlistentity primary key (id)
);
create sequence Wishlist;


# --- !Downs

drop table if exists itementity cascade;
drop sequence if exists Item;

drop table if exists productentity cascade;
drop sequence if exists Product;

drop table if exists wishlistentity cascade;
drop sequence if exists Wishlist;

